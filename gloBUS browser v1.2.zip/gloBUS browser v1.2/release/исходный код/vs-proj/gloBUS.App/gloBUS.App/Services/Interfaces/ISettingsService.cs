﻿using System;
using System.Collections.Generic;
using System.Text;

namespace gloBUS_browser.Services.Interfaces
{
    internal class ISettingsService
    {
    }
}
