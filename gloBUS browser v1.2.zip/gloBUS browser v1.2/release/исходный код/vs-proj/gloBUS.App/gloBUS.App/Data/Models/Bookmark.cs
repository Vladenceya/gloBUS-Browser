﻿using System;
using System.Collections.Generic;
using System.Text;

namespace gloBUS_browser.Data.Models
{
    internal class Bookmark
    {
    }
}
