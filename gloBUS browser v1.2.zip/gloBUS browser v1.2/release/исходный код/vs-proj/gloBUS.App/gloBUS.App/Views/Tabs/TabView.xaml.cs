﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace gloBUS_browser.Views.Tabs
{
    /// <summary>
    /// Логика взаимодействия для TabView.xaml
    /// </summary>
    public partial class TabView : Page
    {
        public TabView()
        {
            InitializeComponent();
        }
    }
}
