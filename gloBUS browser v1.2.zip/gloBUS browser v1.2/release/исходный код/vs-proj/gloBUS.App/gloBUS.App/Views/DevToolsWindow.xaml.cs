﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace gloBUS_browser.Views
{
    /// <summary>
    /// Логика взаимодействия для DevToolsWindow.xaml
    /// </summary>
    public partial class DevToolsWindow : Window
    {
        public DevToolsWindow()
        {
            InitializeComponent();
        }
    }
}
