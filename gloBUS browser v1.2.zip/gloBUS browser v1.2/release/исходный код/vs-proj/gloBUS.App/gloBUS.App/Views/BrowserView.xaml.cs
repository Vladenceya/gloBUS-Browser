﻿using System.Windows.Controls;

namespace gloBUS.App.Views
{
    public partial class BrowserView : UserControl
    {
        public BrowserView()
        {
            InitializeComponent();
            InitializeBrowser();
        }

        private async void InitializeBrowser()
        {
            await Browser.EnsureCoreWebView2Async();
            Browser.CoreWebView2.Navigate("https://www.google.com");
        }
    }
}