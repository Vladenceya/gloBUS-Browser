﻿using System;
using System.Collections.Generic;
using System.Text;

namespace gloBUS_browser.ViewModels.Base
{
    internal class RelayCommand
    {
    }
}
