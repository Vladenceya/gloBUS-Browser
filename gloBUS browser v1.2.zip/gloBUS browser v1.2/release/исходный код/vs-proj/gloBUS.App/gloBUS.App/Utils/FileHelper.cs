﻿using System;
using System.Collections.Generic;
using System.Text;

namespace gloBUS_browser.Utils
{
    internal class FileHelper
    {
    }
}
